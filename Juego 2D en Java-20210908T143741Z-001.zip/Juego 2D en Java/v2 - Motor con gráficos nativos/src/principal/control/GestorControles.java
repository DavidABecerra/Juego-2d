package principal.control;

public class GestorControles {
	public static final Teclado teclado = new Teclado();
	// public static final Raton raton = new Raton();
}
